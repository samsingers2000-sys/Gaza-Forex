---
name: Asia Gaza Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#414755'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#717786'
  outline-variant: '#c1c6d7'
  surface-tint: '#005bc1'
  primary: '#0058bc'
  on-primary: '#ffffff'
  primary-container: '#0070eb'
  on-primary-container: '#fefcff'
  inverse-primary: '#adc6ff'
  secondary: '#52606c'
  on-secondary: '#ffffff'
  secondary-container: '#d5e4f3'
  on-secondary-container: '#586673'
  tertiary: '#9e3d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#c64f00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#d5e4f3'
  secondary-fixed-dim: '#b9c8d7'
  on-secondary-fixed: '#0f1d28'
  on-secondary-fixed-variant: '#3a4854'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb595'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7c2e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-caps:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  container-max: 1440px
  gutter: 16px
---

## Brand & Style

The design system is engineered for a high-performance trading environment, balancing the urgency of financial markets with a serene, trust-inducing aesthetic. The brand personality is professional, precise, and technologically advanced, specifically tailored for the MENA region's financial sector.

The visual direction utilizes a **Modern Glassmorphic** approach. By combining high-transparency layers with soft light blue accents, the UI achieves a sense of "digital air"—lightweight yet structured. This style ensures that complex data visualizations remain legible while maintaining a premium, high-tech feel. The emotional response is one of clarity and calculated confidence.

## Colors

The palette is anchored by "Azure Clarity" (Primary) and "Atmospheric White" (Background). The use of light blue is intentional to reduce eye strain during long trading sessions compared to high-contrast dark modes or harsh pure-white backgrounds.

- **Primary:** A vibrant blue for calls to action and active states.
- **Secondary:** A soft azure used for subtle highlights and glassmorphic tints.
- **Neutral:** A range of slate grays to provide professional grounding for text and borders.
- **Functional (Success/Danger/Warning):** High-chroma green and red are reserved strictly for market movements (Profit/Loss) and execution buttons (Buy/Sell), ensuring immediate cognitive recognition.

## Typography

This design system employs a dual-purpose typographic strategy. **Be Vietnam Pro** is used for the primary UI and Arabic text rendering due to its clean, modern terminals and excellent legibility in professional contexts. 

For financial data, tickers, and price action, **JetBrains Mono** is utilized as a secondary font. Its monospaced nature ensures that jumping numbers in a trading ladder or ticker tape do not cause layout shift, providing a stable reading experience for fast-moving data.

**Arabic Support:** Ensure the line-height for Arabic script is increased by 20% relative to English equivalents to accommodate diacritics and script height.

## Layout & Spacing

The design system follows a strict **8px grid system** to maintain mathematical harmony. 

- **Desktop:** 12-column fluid grid with 24px margins. Trading terminals should use a "Panel" approach where individual modules (Chart, Order Book, History) are separated by 8px or 16px gaps.
- **Mobile:** 4-column grid with 16px margins.
- **Density:** Provide two density modes. "Default" for casual browsing and "Compact" for active trading views where information density is prioritized over whitespace.

## Elevation & Depth

Depth is conveyed through **Glassmorphism and Tonal Layering** rather than traditional heavy shadows.

- **Level 1 (Surface):** Pure white background or very light azure tint (#F8FAFC).
- **Level 2 (Cards):** Semi-transparent white (Opacity 70%) with a 12px Backdrop Blur and a 1px solid white border (Opacity 40%).
- **Level 3 (Popovers/Modals):** Increased backdrop blur (20px) with a subtle ambient shadow: `0 20px 25px -5px rgba(0, 122, 255, 0.05)`.

The 1px border on cards acts as a "light rim," simulating a physical glass edge and providing definition against light backgrounds.

## Shapes

The shape language is "Softly Technical." Rounded corners are used to make the professional environment feel approachable, but they are not so extreme as to appear playful.

- **Standard Elements:** 8px (0.5rem) radius for buttons and input fields.
- **Containers/Cards:** 16px (1rem) radius for primary dashboard modules.
- **Data Tags:** Fully rounded (pill) for status indicators and chips.

## Components

### Buttons
- **Action Buttons:** Large, 8px rounded corners. "Buy" uses Success Green; "Sell" uses Danger Red. Use high-contrast white text for readability.
- **Ghost Buttons:** Primary blue outline with a soft blue hover fill (10% opacity).

### Glassmorphism Cards
All dashboard modules must reside in cards with a `backdrop-filter: blur(12px)`. The background should be `rgba(255, 255, 255, 0.8)` with a `1px` white border at `50%` opacity to define the edges against the sky-blue accents.

### Input Fields
Inputs are minimal: bottom border only or a very light 1px gray border. Use a focus state that glows with the primary light blue. Label text should be small and uppercase.

### Data Visualization
- **Candlestick Charts:** Use Success Green and Danger Red with 0px border radius.
- **Area Charts:** Use Primary Blue with a gradient fill transitioning from 30% opacity to 0% at the baseline.
- **Grid Lines:** Use a very faint neutral (#E2E8F0) to keep the focus on the data.

### Trading Indicators
Status chips (Open/Closed/Pending) use small, pill-shaped backgrounds with the corresponding functional color at 15% opacity and the text at 100% opacity.